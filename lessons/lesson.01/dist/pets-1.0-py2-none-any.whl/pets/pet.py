cat_name = 'Richard'
dog_name = 'Proxor'

# camelCase, snake_case, kebab-case


def bark():
    return 'Woof! Woof!'


def meow():
    print('Meow meow')

